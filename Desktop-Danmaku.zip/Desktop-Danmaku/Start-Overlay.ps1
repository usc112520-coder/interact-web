param([switch]$ValidateOnly,[switch]$SmokeTest)
$ErrorActionPreference = 'Stop'
Add-Type -AssemblyName PresentationFramework,PresentationCore,WindowsBase,System.Xaml,System.Net.Http,System.Web.Extensions,System.Windows.Forms,System.Drawing
$refs = @('PresentationFramework','PresentationCore','WindowsBase','System.Xaml','System.Net.Http','System.Web.Extensions','System.Windows.Forms','System.Drawing') | ForEach-Object { [Reflection.Assembly]::LoadWithPartialName($_).Location }
Add-Type -Path (Join-Path $PSScriptRoot 'DesktopOverlay.cs') -ReferencedAssemblies $refs
if ($ValidateOnly) { [InterActDesktop.OverlayApp]::Validate(); Write-Output 'Overlay compiled; message parsing and scheduling checks passed.'; exit }
[InterActDesktop.OverlayApp]::Run((Join-Path $PSScriptRoot 'InterAct.config.json'), [bool]$SmokeTest)
