using System;
using System.Collections;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Net.Http;
using System.Runtime.InteropServices;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Web.Script.Serialization;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Interop;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Media.Effects;
using System.Windows.Threading;
using Forms = System.Windows.Forms;

namespace InterActDesktop {
  public static class OverlayApp {
    public static void Run(string configPath, bool smoke) {
      var app = new Application { ShutdownMode = ShutdownMode.OnExplicitShutdown };
      var controller = new OverlayController(app, configPath, smoke);
      app.Startup += delegate { controller.Start(); };
      app.Exit += delegate { controller.Dispose(); };
      app.Run();
    }
    public static void Validate() {
      if (OverlayController.MessageText(new Dictionary<string,object>{{"content","hello"},{"participant_name","Student"}},true)!="hello") throw new Exception("Anonymous message failed");
      if (OverlayController.MessageText(new Dictionary<string,object>{{"content","hello"},{"participant_name","Student"}},false)!="Student：hello") throw new Exception("Named message failed");
      if (OverlayController.MessageText(new Dictionary<string,object>{{"content",new string('a',250)}},true).Length>181) throw new Exception("Message limit failed");
      if (!Regex.IsMatch("ABC234", "^[A-Z2-9]{6}$")) throw new Exception("Code validation failed");
    }
  }
  public sealed class OverlayController : IDisposable {
    [DllImport("user32.dll", EntryPoint="GetWindowLong")] static extern int GetStyle(IntPtr h,int i);
    [DllImport("user32.dll", EntryPoint="SetWindowLong")] static extern int SetStyle(IntPtr h,int i,int v);
    [DllImport("user32.dll")] static extern bool SetWindowPos(IntPtr h,IntPtr after,int x,int y,int cx,int cy,uint flags);
    [DllImport("user32.dll")] static extern bool RegisterHotKey(IntPtr h,int id,uint mods,uint key);
    [DllImport("user32.dll")] static extern bool UnregisterHotKey(IntPtr h,int id);
    const int ExTransparent=0x20, ExTool=0x80, ExNoActivate=0x08000000;
    readonly Application app; readonly string configPath; readonly bool smoke;
    readonly JavaScriptSerializer json=new JavaScriptSerializer();
    readonly HttpClient http=new HttpClient { Timeout=TimeSpan.FromSeconds(12) };
    readonly HashSet<string> seen=new HashSet<string>();
    readonly Queue<string> seenOrder=new Queue<string>();
    readonly Queue<string> pending=new Queue<string>();
    readonly double[] available=new double[8];
    readonly List<TextBlock> active=new List<TextBlock>();
    Window overlay,panel; Canvas canvas; TextBox codeInput; TextBlock status; Button connect,pause;
    Forms.NotifyIcon tray; DispatcherTimer poll,animation; HwndSource source; IntPtr hwnd;
    string host="",sessionId=""; bool busy,paused,enabled=true,anonymous=true,disposed; int generation;
    public OverlayController(Application a,string c,bool s){app=a;configPath=c;smoke=s;}
    public void Start(){
      overlay=new Window { Title="實踐大學數遊系｜透明彈幕",WindowStyle=WindowStyle.None,AllowsTransparency=true,Background=Brushes.Transparent,Topmost=true,ShowInTaskbar=false,ShowActivated=false,ResizeMode=ResizeMode.NoResize,Left=SystemParameters.VirtualScreenLeft,Top=SystemParameters.VirtualScreenTop,Width=SystemParameters.VirtualScreenWidth,Height=SystemParameters.VirtualScreenHeight };
      canvas=new Canvas { IsHitTestVisible=false,ClipToBounds=true,Background=Brushes.Transparent };overlay.Content=canvas;
      overlay.SourceInitialized+=delegate {
        hwnd=new WindowInteropHelper(overlay).Handle;
        SetStyle(hwnd,-20,GetStyle(hwnd,-20)|ExTransparent|ExTool|ExNoActivate);
        SetWindowPos(hwnd,new IntPtr(-1),0,0,0,0,0x0013);
        source=HwndSource.FromHwnd(hwnd);source.AddHook(Hook);
        bool hotkeys=RegisterHotKey(hwnd,1,0x4003,0x44)&RegisterHotKey(hwnd,2,0x4003,0x51);
        if(!hotkeys&&!smoke)SetStatus("快捷鍵被其他程式佔用，請用右下角系統匣控制。");
      };
      overlay.Show();
      animation=new DispatcherTimer {Interval=TimeSpan.FromMilliseconds(80)};
      animation.Tick+=delegate{Drain();};animation.Start();
      if(smoke){
        var style=GetStyle(hwnd,-20);
        if((style&ExTransparent)==0||(style&ExNoActivate)==0||!overlay.AllowsTransparency||!overlay.Topmost)throw new Exception("Transparent click-through window verification failed");
        pending.Enqueue("實踐大學數遊系｜透明、置頂、滑鼠穿透測試");
        var end=new DispatcherTimer {Interval=TimeSpan.FromSeconds(3)};
        end.Tick+=delegate{end.Stop();if(active.Count==0)throw new Exception("Animation did not start");Console.WriteLine("PASS: transparent/topmost/click-through/no-activate window and moving text.");app.Shutdown();};end.Start();return;
      }
      BuildPanel();BuildTray();
      try {
        var config=json.Deserialize<Dictionary<string,object>>(File.ReadAllText(configPath));
        string project=Str(config,"ref"),key=Str(config,"key");
        if(!Regex.IsMatch(project,"^[a-z0-9]{20}$")||!Regex.IsMatch(key,"^sb_publishable_[A-Za-z0-9_-]+$"))throw new Exception("公開連線設定格式不正確。");
        host="https://"+project+".supabase.co/rest/v1/";
        http.DefaultRequestHeaders.Add("apikey",key);
      } catch {SetStatus("找不到有效的 InterAct.config.json，請使用完整工具資料夾。");connect.IsEnabled=false;}
      poll=new DispatcherTimer {Interval=TimeSpan.FromSeconds(2)};
      poll.Tick+=async delegate{await Poll(false);};poll.Start();
      panel.Show();
    }
    void BuildPanel(){
      panel=new Window {Title="實踐大學數遊系｜桌面彈幕控制",Width=470,Height=410,ResizeMode=ResizeMode.CanMinimize,WindowStartupLocation=WindowStartupLocation.CenterScreen,Background=new SolidColorBrush(Color.FromRgb(246,246,252))};
      var box=new StackPanel {Margin=new Thickness(24)};panel.Content=box;
      box.Children.Add(new TextBlock {Text="全桌面透明彈幕",FontSize=25,FontWeight=FontWeights.Bold,Margin=new Thickness(0,0,0,10)});
      box.Children.Add(new TextBlock {Text="先在網頁建立場次，輸入 6 碼場次代碼。\n只顯示連線後的新訊息，並遵循網頁的彈幕開關。",TextWrapping=TextWrapping.Wrap,Margin=new Thickness(0,0,0,12)});
      codeInput=new TextBox {FontSize=25,MaxLength=6,CharacterCasing=CharacterCasing.Upper,Margin=new Thickness(0,0,0,10)};box.Children.Add(codeInput);
      connect=new Button {Content="連接場次",Padding=new Thickness(8),Margin=new Thickness(0,0,0,8)};
      connect.Click+=async delegate{await Connect();};box.Children.Add(connect);
      var buttons=new WrapPanel();box.Children.Add(buttons);
      var demo=Btn("測試透明彈幕",delegate{pending.Enqueue("實踐大學數遊系｜透明彈幕測試");if(paused)TogglePause();});buttons.Children.Add(demo);
      pause=Btn("暫停",delegate{TogglePause();});buttons.Children.Add(pause);
      buttons.Children.Add(Btn("隱藏控制面板",delegate{panel.Hide();}));
      status=new TextBlock {Text="尚未連接場次",TextWrapping=TextWrapping.Wrap,Margin=new Thickness(0,12,0,8)};box.Children.Add(status);
      box.Children.Add(new TextBlock {Text="Ctrl＋Alt＋D：暫停／恢復　Ctrl＋Alt＋Q：結束\n右下角系統匣圖示可重新開啟控制面板。",FontSize=12,TextWrapping=TextWrapping.Wrap});
      panel.Closing+=delegate{app.Shutdown();};
    }
    Button Btn(string text,Action action){var b=new Button {Content=text,Padding=new Thickness(7),Margin=new Thickness(0,0,7,5)};b.Click+=delegate{action();};return b;}
    void BuildTray(){
      tray=new Forms.NotifyIcon {Icon=System.Drawing.SystemIcons.Information,Text="實踐大學數遊系｜桌面彈幕",Visible=true};
      var menu=new Forms.ContextMenuStrip();
      menu.Items.Add("開啟控制面板",null,delegate{panel.Show();panel.Activate();});
      menu.Items.Add("暫停／恢復",null,delegate{TogglePause();});
      menu.Items.Add("測試彈幕",null,delegate{pending.Enqueue("實踐大學數遊系｜透明彈幕測試");});
      menu.Items.Add("結束彈幕",null,delegate{app.Shutdown();});tray.ContextMenuStrip=menu;
      tray.DoubleClick+=delegate{panel.Show();panel.Activate();};
    }
    async Task<Dictionary<string,object>[]> Get(string path){
      using(var response=await http.GetAsync(host+path)){
        if(!response.IsSuccessStatusCode)throw new Exception("後端讀取失敗（HTTP "+(int)response.StatusCode+"），請確認公開金鑰與資料庫讀取權限。");
        return json.Deserialize<Dictionary<string,object>[]>(await response.Content.ReadAsStringAsync());
      }
    }
    async Task Connect(){
      string code=codeInput.Text.Trim().ToUpperInvariant();
      if(!Regex.IsMatch(code,"^[A-Z2-9]{6}$")){SetStatus("請輸入 6 碼英數場次代碼。");return;}
      if(busy)return;
      busy=true;connect.IsEnabled=false;int token=++generation;sessionId="";Clear();seen.Clear();seenOrder.Clear();
      try {
        var sessions=await Get("sessions?select=id,code,status,danmaku_enabled,anonymous_enabled&code=eq."+Uri.EscapeDataString(code)+"&limit=1");
        if(sessions.Length==0)throw new Exception("找不到場次，請確認代碼與網頁後端專案相同。");
        if(Str(sessions[0],"status")=="ended")throw new Exception("此場次已結束，請在網頁建立新場次。");
        var id=Str(sessions[0],"id");
        if(!Regex.IsMatch(id,"^[a-fA-F0-9-]{36}$"))throw new Exception("場次識別碼不正確。");
        var initial=await Get("messages?select=id&session_id=eq."+id+"&order=created_at.desc&limit=100");
        if(disposed||token!=generation)return;
        foreach(var row in initial)Remember(Str(row,"id"));
        sessionId=id;enabled=Bool(sessions[0],"danmaku_enabled");anonymous=Bool(sessions[0],"anonymous_enabled");
        SetStatus("已連接 "+code+(enabled?"，等待學生新訊息。":"；請在網頁教學控制中開啟彈幕。"));
        tray.ShowBalloonTip(2500,"桌面彈幕已連接","透明視窗已啟用，可切換到 PPT。右鍵系統匣圖示可控制。",Forms.ToolTipIcon.Info);
        panel.Hide();
      }catch(Exception error){SetStatus(error.Message);}finally{busy=false;if(!disposed)connect.IsEnabled=true;}
    }
    async Task Poll(bool unused){
      if(disposed||busy||sessionId.Length==0)return;
      busy=true;int token=generation;string id=sessionId;
      try{
        var sessions=await Get("sessions?select=status,danmaku_enabled,anonymous_enabled&id=eq."+id+"&limit=1");
        if(disposed||token!=generation)return;
        if(sessions.Length==0||Str(sessions[0],"status")=="ended"){sessionId="";Clear();SetStatus("場次已結束或不存在，已停止桌面彈幕。");return;}
        enabled=Bool(sessions[0],"danmaku_enabled");anonymous=Bool(sessions[0],"anonymous_enabled");
        var rows=await Get("messages?select=id,content,participant_name,created_at&session_id=eq."+id+"&order=created_at.desc&limit=100");
        if(disposed||token!=generation)return;
        for(int i=rows.Length-1;i>=0;i--){var row=rows[i];string messageId=Str(row,"id");if(Remember(messageId)&&enabled&&!paused){string text=MessageText(row,anonymous);if(text.Length>0&&pending.Count<100)pending.Enqueue(text);}}
        if(!enabled)Clear();
        SetStatus(paused?"桌面彈幕已暫停":enabled?"已連線，等待學生新訊息。":"網頁彈幕已關閉。");
        SetWindowPos(hwnd,new IntPtr(-1),0,0,0,0,0x0013);
      }catch(Exception error){SetStatus(error.Message+" 正在重試。");}finally{busy=false;}
    }
    bool Remember(string id){if(id.Length==0||!seen.Add(id))return false;seenOrder.Enqueue(id);while(seenOrder.Count>2000)seen.Remove(seenOrder.Dequeue());return true;}
    public static string MessageText(Dictionary<string,object> row,bool anon){
      string content=Regex.Replace(Str(row,"content"),"[\\r\\n\\t]+"," ").Trim();if(content.Length>180)content=content.Substring(0,180)+"…";
      if(content.Length==0)return "";string name=Str(row,"participant_name");return anon||name.Length==0?content:name+"："+content;
    }
    static string Str(Dictionary<string,object> d,string key){object value;return d.TryGetValue(key,out value)&&value!=null?Convert.ToString(value,CultureInfo.InvariantCulture):"";}
    static bool Bool(Dictionary<string,object> d,string key){object value;return d.TryGetValue(key,out value)&&value is bool&&(bool)value;}
    void Drain(){
      if(paused||pending.Count==0)return;
      double now=DateTime.UtcNow.Ticks/(double)TimeSpan.TicksPerSecond;
      int lanes=Math.Max(1,Math.Min(8,(int)((overlay.Height-80)/65)));
      for(int lane=0;lane<lanes&&pending.Count>0;lane++){
        if(available[lane]>now)continue;
        var text=new TextBlock {Text=pending.Dequeue(),FontFamily=new FontFamily("Microsoft JhengHei"),FontSize=34,FontWeight=FontWeights.Bold,Foreground=Brushes.White,Effect=new DropShadowEffect {Color=Colors.Black,BlurRadius=5,ShadowDepth=1,Opacity=1},IsHitTestVisible=false};
        text.Measure(new Size(double.PositiveInfinity,double.PositiveInfinity));double width=text.DesiredSize.Width;
        Canvas.SetTop(text,30+lane*65);var move=new TranslateTransform(overlay.Width,0);text.RenderTransform=move;canvas.Children.Add(text);active.Add(text);
        double speed=160;available[lane]=now+(width+90)/speed;
        var animation=new DoubleAnimation(overlay.Width,-width-20,TimeSpan.FromSeconds((overlay.Width+width+20)/speed));
        animation.Completed+=delegate{canvas.Children.Remove(text);active.Remove(text);};move.BeginAnimation(TranslateTransform.XProperty,animation);
      }
    }
    void Clear(){pending.Clear();foreach(var item in active){var transform=item.RenderTransform as TranslateTransform;if(transform!=null)transform.BeginAnimation(TranslateTransform.XProperty,null);}active.Clear();canvas.Children.Clear();Array.Clear(available,0,available.Length);}
    void TogglePause(){paused=!paused;Clear();if(pause!=null)pause.Content=paused?"恢復":"暫停";SetStatus(paused?"桌面彈幕已暫停":"桌面彈幕已恢復");}
    void SetStatus(string text){if(status!=null)status.Text=text;}
    IntPtr Hook(IntPtr h,int message,IntPtr w,IntPtr l,ref bool handled){if(message==0x0312){if(w.ToInt32()==1)TogglePause();if(w.ToInt32()==2)app.Shutdown();handled=true;}return IntPtr.Zero;}
    public void Dispose(){if(disposed)return;disposed=true;generation++;if(poll!=null)poll.Stop();if(animation!=null)animation.Stop();http.Dispose();if(hwnd!=IntPtr.Zero){UnregisterHotKey(hwnd,1);UnregisterHotKey(hwnd,2);}if(tray!=null){tray.Visible=false;tray.Dispose();}if(source!=null)source.RemoveHook(Hook);}
  }
}
